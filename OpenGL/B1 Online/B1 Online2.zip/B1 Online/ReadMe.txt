press a to animate
press up down arrow key to change the height of the camera